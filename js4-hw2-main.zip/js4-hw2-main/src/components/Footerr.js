function Footer() {
	return (
		<header>
			<nav class='contain'>
				<div>
					logo
					<ul>
						<li>Home</li>
						<li>About</li>
						<li>contact</li>
						<li>catalog</li>
					</ul>
					<div>cart</div>
				</div>
			</nav>
		</header>
	)
}

export default Footer
